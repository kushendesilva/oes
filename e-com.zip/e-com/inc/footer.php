</div>
   <div class="footer">
   	  <div class="wrapper">	
	     <div class="section group">
				<div class="col_1_of_4 span_1_of_4">
						
					</div>
				<div class="col_1_of_4 span_1_of_4">
					
				</div>
				<div class="col_1_of_4 span_1_of_4">
					
				</div>
				<div class="col_1_of_4 span_1_of_4">
					
						<div class="social-icons">
							
   	 					</div>
				</div>
			</div>

     </div>
    </div>
    <script type="text/javascript">
		$(document).ready(function() {

			
			$().UItoTop({ easingType: 'easeOutQuart' });
			
		});
	</script>
    <a href="#" id="toTop" style="display: block;"><span id="toTopHover" style="opacity: 1;"></span></a>
    <link href="css/flexslider.css" rel='stylesheet' type='text/css' />
	  <script defer src="js/jquery.flexslider.js"></script>
	  <script type="text/javascript">
		$(function(){
		  SyntaxHighlighter.all();
		});
		$(window).load(function(){
		  $('.flexslider').flexslider({
			animation: "slide",
			start: function(slider){
			  $('body').removeClass('loading');
			}
		  });
		});
	  </script>
</body>
</html>
